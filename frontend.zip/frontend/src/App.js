import React from 'react';
import GradePrediction from './Components/GradePrediction.js';

function App() {
  return (
    <div className="App">
      <GradePrediction />
    </div>
  );
}

export default App;
