import React, { useState } from 'react';
import axios from 'axios';
import validateForm from './ValidationForm';

function GradePrediction() {
  const [formData, setFormData] = useState({
    G1: '',
    G2: '',
    studytime: '',
    absences: '',
    famsup: 'yes',  // Default value for famsup
    schoolsup: 'yes',  // Default value for schoolsup
    health: 3,  // Default health value (out of 5)
    famrel: 4,  // Default famrel value (out of 5)
    internet: 'yes', // Default value for internet
    failures: '', // Default value for failures
  });

  const [prediction, setPrediction] = useState(null);
  const [error, setError] = useState(null);

  // Cập nhật giá trị nhập vào
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // Gửi yêu cầu đến backend Flask
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate form
    const errors = validateForm(formData);
    if (errors.length > 0) {
      setError(errors.join('. '));
      setPrediction(null);
      return;
    }

    // Chuẩn bị dữ liệu cần gửi
    const dataToSend = {
      features: [
        parseFloat(formData.studytime),
        parseInt(formData.failures),
        parseInt(formData.famrel),
        parseInt(formData.health),
        formData.internet, // giữ nguyên 'yes' hoặc 'no'
        parseInt(formData.absences),
        formData.famsup,   // giữ nguyên 'yes' hoặc 'no'
        formData.schoolsup, // giữ nguyên 'yes' hoặc 'no'
        parseFloat(formData.G1),
        parseFloat(formData.G2)
      ]
    };
    try {
      // Gửi yêu cầu POST đến API Flask
      const response = await axios.post('http://127.0.0.1:5000/predict', dataToSend);

      // Nhận kết quả dự đoán
      setPrediction(response.data.prediction);
      setError(null); // Xóa lỗi nếu có
    } catch (error) {
      setError('Có lỗi xảy ra khi gửi yêu cầu.');
      setPrediction(null); // Xóa dự đoán nếu có lỗi
    }
  };

  return (
    <div>
      <h1>Grade Prediction</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>G1 (First Period Grade): </label>
          <input
            type="number"
            name="G1"
            value={formData.G1}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>G2 (Second Period Grade): </label>
          <input
            type="number"
            name="G2"
            value={formData.G2}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Study Time (hours/week): </label>
          <input
            type="number"
            name="studytime"
            value={formData.studytime}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Absences: </label>
          <input
            type="number"
            name="absences"
            value={formData.absences}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Family Support (famsup): </label>
          <select name="famsup" value={formData.famsup} onChange={handleChange} required>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div>
          <label>School Support (schoolsup): </label>
          <select name="schoolsup" value={formData.schoolsup} onChange={handleChange} required>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div>
          <label>Health Status (1 to 5): </label>
          <input
            type="number"
            name="health"
            value={formData.health}
            onChange={handleChange}
            min="1"
            max="5"
            required
          />
        </div>
        <div>
          <label>Family Relationship (1 to 5): </label>
          <input
            type="number"
            name="famrel"
            value={formData.famrel}
            onChange={handleChange}
            min="1"
            max="5"
            required
          />
        </div>
        <div>
          <label>Internet Access (internet): </label>
          <select name="internet" value={formData.internet} onChange={handleChange} required>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>
        <div>
          <label>Failures (số lần thất bại): </label>
          <input
            type="number"
            name="failures"
            value={formData.failures}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Predict</button>
      </form>

      {prediction && <p>Predicted Grade (G3): {prediction}</p>}
      {error && (
        <div className="error">
          {error.split('. ').map((err, idx) =>
            err.trim() ? <div key={idx}>{err}</div> : null
          )}
        </div>
      )}
    </div>
  );
}

export default GradePrediction;
