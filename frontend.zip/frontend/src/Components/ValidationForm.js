// Hàm kiểm tra dữ liệu đầu vào
function validateForm(formData) {
    const errors = [];
    // G1, G2: 0 - 20
    if (formData.G1 === '' || isNaN(formData.G1) || formData.G1 < 0 || formData.G1 > 20) {
      errors.push('G1 phải là số từ 0 đến 20');
    }
    if (formData.G2 === '' || isNaN(formData.G2) || formData.G2 < 0 || formData.G2 > 20) {
      errors.push('G2 phải là số từ 0 đến 20');
    }
    // studytime: 1 - 4
    if (formData.studytime === '' || isNaN(formData.studytime) || formData.studytime < 1 || formData.studytime > 4) {
      errors.push('Studytime phải là số nguyên từ 1 đến 4');
    }
    // absences: 0 - 93
    if (formData.absences === '' || isNaN(formData.absences) || formData.absences < 0 || formData.absences > 93) {
      errors.push('Absences phải là số từ 0 đến 93');
    }
    // health: 1 - 5
    if (formData.health === '' || isNaN(formData.health) || formData.health < 1 || formData.health > 5) {
      errors.push('Health phải là số từ 1 đến 5');
    }
    // famrel: 1 - 5
    if (formData.famrel === '' || isNaN(formData.famrel) || formData.famrel < 1 || formData.famrel > 5) {
      errors.push('Famrel phải là số từ 1 đến 5');
    }
    // failures: 0 - 3
    if (formData.failures === '' || isNaN(formData.failures) || formData.failures < 0 || formData.failures > 3) {
      errors.push('Failures phải là số nguyên từ 0 đến 3');
    }
    return errors;
  }

  export default validateForm;